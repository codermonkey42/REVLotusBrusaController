/*
 *REV Lotus Charger Control over CANBus code v1.0
 * coded by Alishan Aziz
 * STM32F303k* nucleo board reads CANBus messages from ZEVA EVMS3
 * extracts voltage and amp hours of battery pack
 * passes voltage demand and current demand over to the charger
 * CAN Baud 500Kbps
 */

#include "CANMsg.h"
#include "math.h"
#include "mbed.h"
#include <cstdint>
#include <inttypes.h>

#define RX_ID 0x000A0100
#define TX_ID 0x00000101
#define ZEVA_PARAMS_RX_ID 30
#define CHARGER_TX_ID 0x618
#define CHARGER_DIAGREQ_TX_I 0x718
#define CHARGER_STATUSBITS_RX_ID 0x610
#define CHARGER_MAINSTATUS_RX_ID 0x611
#define CHARGER_MAINSCURRENT_AUXVOLT_RX_ID 0x612
#define CHARGER_TEMPERATURES_RX_ID 0x613
#define CHARGER_ERROR_FLAG_RX_ID 0x614

#define CHARGER_INSTRUCTION_SEND_RATE 100 // 100ms
#define CAN_BAUD_RATE 250000               // 500Kbps
#define SERIAL_BAUD_RATE 115200
#define DEFAULT_MAINS_CURRENT_DEMAND 16    // 16A draw from AC side max
#define DEFAULT_MAX_CHARGING_CURRENT 12.5
#define DEFAULT_MAX_CHARGE_VOLTAGE 266

/***************************** COMMS PIN CONFIGS *****************************/
Serial pc(USBTX, USBRX); // Open serial comms via putty etc to see printfs
CAN can(PA_11, PA_12);   // CAN Rx pin name, CAN Tx pin name

CANMsg rxMsg;
CANMsg txMsg;
InterruptIn commenceChargeButton(PB_1);
DigitalOut led(LED1);
Timer timer;

/***************************** GLOBAL VARIABLES *****************************/
volatile bool newMsgRx = false;
volatile bool commenceCharge = false;

// ZEVA EVMS params
uint8_t errorCode = 0;
uint8_t statusCode = 0;
int zevaTemperature = 0;
int isolationIntegrity = 0;
float ampHoursLeft = 0;
float voltage = 0.0;
float auxVoltage = 0.0;

// Charger params
unsigned int statusBitmap = 0;
float mainsCurrent = 0.0;
float mainsVoltage = 0.0;
float outputVoltage = 0.0;
float outputCurrent = 0.0;
float mainsCurrentLimitSAE = 0.0;
float mainsCurrentLimitPI = 0.0;
float auxBatteryVoltage = 0.0;
float chargerTemperature = 0.0;
float temp1 = 0.0;
float temp2 = 0.0;
float temp3 = 0.0;
long long errorBitmap = 0; // long also limited to 4 bytes, hence long long

/************************ Interrupt Service Routines ************************/
void setChargeCommence() { commenceCharge = true; }

void resetChargeCommence() { commenceCharge = false; }

void onCanReceived(void) {
    can.read(rxMsg);
    newMsgRx = true;
}

/********************************* FUNCTIONS *********************************/
void decodeRxMsg(void) {
    int id = rxMsg.id;  

    uint8_t dataByte, dataByte2;

    switch (id) {
    case ZEVA_PARAMS_RX_ID:    
        rxMsg >> dataByte;
        errorCode = ((dataByte & 0b11111000) >> 3);
        statusCode = dataByte & 0b00000111;

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        ampHoursLeft = ((dataByte << 8) + dataByte2) / 10.0;

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        voltage = ((dataByte << 8) + dataByte2) / 10.0;    

        rxMsg >> dataByte;
        auxVoltage = dataByte / 10.0;    

        rxMsg >> dataByte;
        isolationIntegrity = (dataByte & 0b01111111);

        rxMsg >> dataByte;
        zevaTemperature = dataByte - 40;

        break;
    case CHARGER_STATUSBITS_RX_ID:

        statusBitmap = 0;

        rxMsg >> dataByte;
        statusBitmap = (statusBitmap << 8) + dataByte;

        rxMsg >> dataByte;
        statusBitmap = (statusBitmap << 8) + dataByte;

        rxMsg >> dataByte;
        statusBitmap = (statusBitmap << 8) + dataByte;

        rxMsg >> dataByte;
        statusBitmap = (statusBitmap << 8) + dataByte;

        // pc.printf("Status Bitmap: 0x%x\n\r", statusBitmap);

        if(statusBitmap & 0x40000000){
            
        }
        else {
            
        }

        break;
    case CHARGER_MAINSTATUS_RX_ID:

        // pc.printf("Message length: %d\n\r", len);    
        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        mainsCurrent = ((dataByte << 8) + dataByte2) / 100.0;   
        // pc.printf("Mains current: %f\n\r", mainsCurrent); 

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        mainsVoltage = ((dataByte << 8) + dataByte2) / 10.0;        
        // pc.printf("Mains Voltage: %f\n\r", mainsVoltage);

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        outputVoltage = ((dataByte << 8) + dataByte2) / 10.0;        
        // pc.printf("Output Voltage: %f\n\r", outputVoltage);

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        outputCurrent = ((dataByte << 8) + dataByte2) / 100.0;    
        // pc.printf("Output Current: %f\n\r", outputCurrent);

        break;
    case CHARGER_MAINSCURRENT_AUXVOLT_RX_ID:

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        mainsCurrentLimitSAE = ((dataByte << 8) + dataByte2) / 10.0;

        rxMsg >> dataByte;
        mainsCurrentLimitPI = (dataByte) / 10.0;

        rxMsg >> dataByte;
        auxBatteryVoltage = (dataByte) / 10.0;

        break;
    case CHARGER_TEMPERATURES_RX_ID:

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        chargerTemperature = ((dataByte << 8) + dataByte2) / 10.0;

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        temp1 = ((dataByte << 8) + dataByte2) / 10.0;

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        temp2 = ((dataByte << 8) + dataByte2) / 10.0;

        rxMsg >> dataByte;
        rxMsg >> dataByte2;
        temp3 = ((dataByte << 8) + dataByte2) / 10.0;

        break;
    case CHARGER_ERROR_FLAG_RX_ID:

        errorBitmap = 0;

        rxMsg >> dataByte;
        errorBitmap = ((errorBitmap) << 8) + dataByte;

        rxMsg >> dataByte;
        errorBitmap = ((errorBitmap) << 8) + dataByte;

        rxMsg >> dataByte;
        errorBitmap = ((errorBitmap) << 8) + dataByte;

        rxMsg >> dataByte;
        errorBitmap = ((errorBitmap) << 8) + dataByte;

        rxMsg >> dataByte;
        errorBitmap = ((errorBitmap) << 8) + dataByte;

        // pc.printf("ErrorBitmap: 0d%jx,\n\r", errorBitmap);

        break;
    }  
    newMsgRx = false;
}

/********************************* MAIN LOOP *********************************/
int main(void) {
    bool toggleMsg = false; // used to clear errors
    pc.baud(SERIAL_BAUD_RATE); // set serial speed
    can.frequency(CAN_BAUD_RATE);

    // attaching ISRs
    can.attach(onCanReceived);                    // handle received CAN messages
    commenceChargeButton.rise(setChargeCommence); // 0V to 12V chg en transition
    commenceChargeButton.fall(resetChargeCommence); // 12V to 0V chg en transition

    timer.start(); // start timer
    pc.printf("\r ***** Lotus Charger Control Firmware *****\n\r");

    while (1) {
        if (newMsgRx) {
            decodeRxMsg();
        }
        
        if (timer.read_ms() >= CHARGER_INSTRUCTION_SEND_RATE) {
            timer.stop();
            timer.reset();    

            txMsg.clear();            // clear Tx message storage
            txMsg.id = CHARGER_TX_ID; // set ID

            uint8_t txDataByte; // byte-wise formation of packet

            if(errorBitmap != 0){
                if(toggleMsg){
                    txDataByte = 0b00000000;
                }
                else{
                    txDataByte = 0b01000000;
                }     
                toggleMsg = !toggleMsg;           
            }    
            else{
                if(commenceCharge){
                    txDataByte = 0b10000000;
                    led = true;
                }
                else{
                    txDataByte = 0b00000000;
                    led = false;
                }
            }

            txMsg << txDataByte; // one byte

            txDataByte = ((DEFAULT_MAINS_CURRENT_DEMAND * 10) & 0xFF00) >> 8;
            txMsg << txDataByte;

            txDataByte = ((DEFAULT_MAINS_CURRENT_DEMAND * 10) & 0x00FF);
            txMsg << txDataByte;

            uint16_t desiredVoltage = ceil(voltage) + 1;

            if(desiredVoltage > DEFAULT_MAX_CHARGE_VOLTAGE){
                desiredVoltage = DEFAULT_MAX_CHARGE_VOLTAGE;
            }

            txDataByte = ((desiredVoltage * 10) & 0xFF00) >> 8;
            txMsg << txDataByte;

            txDataByte = ((desiredVoltage * 10) & 0x00FF);
            txMsg << txDataByte;

            txDataByte = (((int)(DEFAULT_MAX_CHARGING_CURRENT * 10)) & 0xFF00) >> 8;
            txMsg << txDataByte;

            txDataByte = (((int)(DEFAULT_MAX_CHARGING_CURRENT * 10)) & 0x00FF);
            txMsg << txDataByte;

            if (can.write(txMsg)) { // transmit message
                // pc.printf("Tx Message Successful.\n");
            } else {
                pc.printf("Error transmitting message.\n\r");
            }

            timer.start();
        }
    }
}
/******************************* END PROGRAM *******************************/
