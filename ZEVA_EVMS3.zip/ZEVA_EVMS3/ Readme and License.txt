ZEVA Electric Vehicle Management System V3
  Ian Hooper, August 2021

This archive contains all the files needed to reproduce the ZEVA Electric Vehicle Management System V3 (master controller). Files are provided under the open source MIT license, found at the end of this file. The short version is that you may use these files for any purpose, free of charge, but they don’t come with any warranty or support.

PCB and schematic (.sch) files can be opened in Autodesk Eagle. If you don’t need to modify the design, the Gerber files in the PCB Assembly folder can be sent as-is to a PCB manufacturer to get boards made. PCBs should be standard 1.6mm thickness and 1oz / 35um copper. Files for PCB assembly are also included, such as a Bill of Materials, centroid files (for pick-and-place machines), and example photos for reference. Parts in the Eagle file may not match the BoM in some cases. If in doubt, trust the BoM.

Precharge components can be omitted if not needed: CPC1727 SSR, 2x 100ohm 5W resistors, FOF852 optocoupler and 30Kohm 2512 resistor. These parts are suitable for systems up to 200V max. For a higher voltage precharger (400V max), substitute with CPC1779 SSR, 2x 200ohm resistors, and 68Kohm 2512 resistor.

The firmware is written is C and can be compiled using AVR-GCC, normally using an IDE such as AVR / Microchip Studio. No claims are made about the quality or readability of the code. A precompiled HEX file is also supplied, which can be loaded onto boards as-is if standard firmware is suitable.

You will need an AVRISP type programming device for transferring firmware to the board, such as AVRISP MK2, STK500 or USBASP. The programming port on the PCB is a row of 5 holes near the microcontroller, with pin order GND, MOSI, MISO, SCK, RESET (with GND end marked). It is different to the usual 3x2 or 5x2 pin port used by AVRISP programmers, so you will need to make an adapter using 5 wires and some 0.1” pin header. Normally the 5x1 pin header can be pressed against the PCB holes during programming (avoids the need to add any connector to the board). The board will need to be powered during programming via 12V supplied to the 12V and Ground inputs on the PCB.

AVR microcontrollers use “fuses” for setting things like the clock speed and brownout detection. The required fuse settings are listed near the top of the C code file.

The housing can be 3D printed from the two STL model files. The supplied label can be printed, cut to size and attached to the top cover, fitting between the two slots for terminal blocks and oriented correctly with respect to the CAN ports. The label can be laser printed on to transparent sticker stock such as Avery 959065.

All through hole pins/legs need to be cut pretty short to ensure the PCB fits flush inside the housing (including those for the CAN and temperature ports). The PCB fits inside the top cover, with two terminal blocks on the top side, which can all be held together using 4x M3x20 machine screws and M3 nuts while the terminal block pins are soldered to the PCB. The terminal blocks are Molex 38720-6208, or Curtis CBPW-8 are also suitable. Once soldered, the nuts can be removed, and the 4x M3x20 screws are instead used to fasten the top assembly to the base. The mating connectors for CAN bus ports are Molex 39500-0005 and the cell connector is Molex 39500-0013.

Once assembled and programmed, the EVMS should be ready to use. Please review the user manual for further information about installation and operation.

----------

LICENSE (MIT Open Source):

Copyright (c) 2021 Ian Hooper, ZEVA

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.